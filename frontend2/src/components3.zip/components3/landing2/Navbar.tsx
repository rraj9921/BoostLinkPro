"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, Sparkles, X, Zap } from "lucide-react";
import ThemeToggle from "../theme/ThemeToggle";
import { brandGradient, landingContainerStyle } from "./landingTheme";

const navLinks = [
  ["Features", "#features"],
  ["How it works", "#how"],
  ["Pricing", "#pricing"],
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 18);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <style>{`
        .nav-links,
        .nav-actions {
          display: flex;
          align-items: center;
        }
        .nav-links { gap: 30px; }
        .nav-actions { gap: 10px; }
        .nav-mobile { display: none !important; }
        .nav-link {
          color: var(--text3);
          font-size: 15px;
          font-weight: 700;
          text-decoration: none;
          transition: color .18s ease;
        }
        .nav-link:hover { color: #FF4D00; }
        .nav-cta {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          min-height: 42px;
          padding: 0 18px;
          border-radius: 12px;
          text-decoration: none;
          font-size: 14px;
          font-weight: 800;
          color: white;
          background: ${brandGradient};
          box-shadow: 0 12px 34px rgba(255,77,0,.25);
          transition: transform .2s ease, box-shadow .2s ease;
        }
        .nav-cta:hover {
          transform: translateY(-1px);
          box-shadow: 0 16px 38px rgba(255,77,0,.32);
        }
        @media (max-width: 860px) {
          .nav-links,
          .nav-actions { display: none !important; }
          .nav-mobile { display: flex !important; align-items: center; gap: 8px; }
        }
      `}</style>

      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          borderBottom: scrolled ? "1px solid var(--border)" : "1px solid transparent",
          background: scrolled ? "rgba(var(--bg-rgb,255,255,255),0.82)" : "transparent",
          backdropFilter: scrolled ? "blur(28px) saturate(180%)" : "none",
          WebkitBackdropFilter: scrolled ? "blur(28px) saturate(180%)" : "none",
          boxShadow: scrolled ? "0 8px 36px rgba(0,0,0,.06)" : "none",
          transition: "all .28s cubic-bezier(.16,1,.3,1)",
        }}
      >
        <div
          style={{
            ...landingContainerStyle,
            height: 72,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Link
            href="/"
            style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none" }}
          >
            <div
              style={{
                width: 38,
                height: 38,
                borderRadius: 12,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: brandGradient,
                boxShadow: "0 10px 28px rgba(255,77,0,.28)",
              }}
            >
              <Zap size={17} color="white" fill="white" />
            </div>
            <span style={{ fontSize: 18, fontWeight: 800, color: "var(--text1)", letterSpacing: "-0.03em" }}>
              BoostLink<span style={{ color: "#FF4D00" }}>Pro</span>
            </span>
          </Link>

          <div className="nav-links">
            {navLinks.map(([label, href]) => (
              <a key={label} href={href} className="nav-link">
                {label}
              </a>
            ))}
          </div>

          <div className="nav-actions">
            <ThemeToggle />
            <Link
              href="/auth/login"
              className="nav-link"
              style={{ padding: "8px 10px", borderRadius: 10 }}
            >
              Sign in
            </Link>
            <Link href="/auth/signup" className="nav-cta">
              <Sparkles size={14} />
              Join early access
            </Link>
          </div>

          <div className="nav-mobile">
            <ThemeToggle />
            <button
              onClick={() => setOpen((value) => !value)}
              style={{
                background: "none",
                border: "none",
                color: "var(--text1)",
                padding: 8,
                borderRadius: 10,
                cursor: "pointer",
                display: "flex",
              }}
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {open && (
          <div
            style={{
              background: "var(--card)",
              borderTop: "1px solid var(--border)",
              padding: "20px 28px 28px",
            }}
          >
            {navLinks.map(([label, href]) => (
              <a
                key={label}
                href={href}
                onClick={() => setOpen(false)}
                style={{
                  display: "block",
                  padding: "13px 0",
                  fontSize: 16,
                  fontWeight: 700,
                  color: "var(--text2)",
                  textDecoration: "none",
                  borderBottom: "1px solid var(--border)",
                }}
              >
                {label}
              </a>
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
              <Link
                href="/auth/login"
                onClick={() => setOpen(false)}
                style={{
                  flex: 1,
                  textAlign: "center",
                  padding: "13px",
                  fontSize: 15,
                  fontWeight: 800,
                  borderRadius: 12,
                  border: "1px solid var(--border)",
                  color: "var(--text2)",
                  textDecoration: "none",
                }}
              >
                Sign in
              </Link>
              <Link
                href="/auth/signup"
                onClick={() => setOpen(false)}
                className="nav-cta"
                style={{ flex: 1 }}
              >
                Join early access
              </Link>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
