import type { CSSProperties } from "react";

export const landingContainerStyle: CSSProperties = {
  maxWidth: 1160,
  margin: "0 auto",
  padding: "0 28px",
  position: "relative",
};

export const sectionPadding = "120px 0";

export const brandGradient = "linear-gradient(135deg, #FF4D00 0%, #FF7A3D 45%, #FFB347 100%)";
export const brandGlow = "0 20px 60px rgba(255,77,0,.24)";
export const darkPanel =
  "linear-gradient(180deg, rgba(25,17,21,.98) 0%, rgba(15,10,14,.98) 100%)";
export const tintedPanel =
  "linear-gradient(180deg, color-mix(in srgb, var(--card) 96%, transparent), color-mix(in srgb, var(--bg2) 92%, transparent))";

export const sectionEyebrowStyle: CSSProperties = {
  fontSize: 12,
  fontWeight: 800,
  letterSpacing: "0.16em",
  textTransform: "uppercase",
  color: "#FF4D00",
  marginBottom: 14,
};

export const sectionTitleStyle: CSSProperties = {
  fontSize: "clamp(34px, 4.8vw, 58px)",
  fontWeight: 800,
  letterSpacing: "-0.035em",
  color: "var(--text1)",
  lineHeight: 1.04,
  marginBottom: 18,
};

export const sectionCopyStyle: CSSProperties = {
  fontSize: 18,
  lineHeight: 1.75,
  color: "var(--text2)",
  maxWidth: 620,
};
