import Link from "next/link";
import { ArrowRight, Sparkles } from "lucide-react";
import { brandGradient, landingContainerStyle } from "../landingTheme";

export default function CtaBanner() {
  return (
    <section
      style={{
        padding: "120px 0",
        background:
          "linear-gradient(180deg, var(--bg) 0%, color-mix(in srgb, var(--bg2) 86%, #fff2eb 14%) 100%)",
      }}
    >
      <div style={landingContainerStyle}>
        <div
          style={{
            position: "relative",
            overflow: "hidden",
            borderRadius: 36,
            padding: "clamp(50px, 7vw, 92px) clamp(28px, 6vw, 86px)",
            background: "linear-gradient(180deg, #1B1016 0%, #140D12 100%)",
            boxShadow: "0 34px 100px rgba(255,77,0,.18)",
            textAlign: "center",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              pointerEvents: "none",
              background:
                "radial-gradient(circle at 18% 0%, rgba(255,77,0,.22), transparent 26%), radial-gradient(circle at 82% 80%, rgba(255,84,126,.16), transparent 28%)",
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              pointerEvents: "none",
              backgroundImage: "radial-gradient(rgba(255,255,255,.14) 1px, transparent 1px)",
              backgroundSize: "22px 22px",
              opacity: 0.12,
            }}
          />

          <div style={{ position: "relative" }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 10,
                padding: "10px 16px",
                borderRadius: 999,
                border: "1px solid rgba(255,255,255,.14)",
                background: "rgba(255,255,255,.05)",
                color: "#F9DED2",
                fontSize: 13,
                fontWeight: 700,
                marginBottom: 24,
              }}
            >
              <Sparkles size={14} color="#FFB347" />
              Professional look, honest messaging, reusable structure
            </div>

            <h2
              style={{
                fontSize: "clamp(32px, 5vw, 58px)",
                lineHeight: 1.05,
                letterSpacing: "-0.04em",
                color: "white",
                fontWeight: 800,
                marginBottom: 18,
              }}
            >
              Start with a landing page that looks
              <br />
              as serious as the product you want to build
            </h2>

            <p
              style={{
                maxWidth: 620,
                margin: "0 auto 34px",
                fontSize: "clamp(16px, 2vw, 20px)",
                lineHeight: 1.78,
                color: "rgba(255,255,255,.72)",
              }}
            >
              You now have a cleaner design direction, stronger pre-launch messaging,
              and a reusable structure that can evolve with real screenshots, plans,
              and traction when those pieces exist.
            </p>

            <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: 14 }}>
              <Link
                href="/auth/signup"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 10,
                  minHeight: 58,
                  padding: "0 28px",
                  borderRadius: 16,
                  textDecoration: "none",
                  fontSize: 16,
                  fontWeight: 800,
                  color: "white",
                  background: brandGradient,
                  boxShadow: "0 18px 50px rgba(255,77,0,.24)",
                }}
              >
                Join early access <ArrowRight size={17} />
              </Link>
            </div>

            <p style={{ marginTop: 18, fontSize: 13, color: "rgba(255,255,255,.56)" }}>
              No fake traction. No inflated proof. Just a better launch-ready foundation.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
