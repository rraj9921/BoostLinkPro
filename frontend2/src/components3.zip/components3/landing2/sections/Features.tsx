"use client";

import { useEffect, useRef } from "react";
import {
  BarChart2,
  Instagram,
  LayoutTemplate,
  MessageCircle,
  Settings2,
  ShieldCheck,
} from "lucide-react";
import SectionIntro from "../SectionIntro";
import { landingContainerStyle, sectionPadding, tintedPanel } from "../landingTheme";

const features = [
  {
    icon: MessageCircle,
    color: "#FF4D00",
    tint: "rgba(255,77,0,.1)",
    title: "Comment-to-DM automation",
    description:
      "Build flows around keywords and intent so your audience gets a fast response when they ask for details, pricing, or access.",
  },
  {
    icon: LayoutTemplate,
    color: "#FF8A3D",
    tint: "rgba(255,138,61,.1)",
    title: "Professional launch-ready UI",
    description:
      "Present the product with the confidence of a serious SaaS brand, even while the platform is still moving through early access.",
  },
  {
    icon: Settings2,
    color: "#FFB347",
    tint: "rgba(255,179,71,.12)",
    title: "Reusable product structure",
    description:
      "Clear sections, reusable design tokens, and consistent patterns make it easier to evolve the site as your roadmap becomes real.",
  },
  {
    icon: Instagram,
    color: "#F2558D",
    tint: "rgba(242,85,141,.1)",
    title: "Instagram-native messaging",
    description:
      "Every section now speaks directly to creators, coaches, and businesses who sell or qualify leads through Instagram conversations.",
  },
  {
    icon: ShieldCheck,
    color: "#F43F5E",
    tint: "rgba(244,63,94,.1)",
    title: "Credible positioning",
    description:
      "No fake social proof, no inflated revenue metrics, and no made-up screenshots. The product story feels polished without overclaiming.",
  },
  {
    icon: BarChart2,
    color: "#8B5CF6",
    tint: "rgba(139,92,246,.11)",
    title: "Ready for future growth",
    description:
      "The design leaves room for analytics, onboarding, pricing, and customer proof when those pieces become real later in the product journey.",
  },
];

export default function Features() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cards = ref.current?.querySelectorAll(".feature-card");
    if (!cards) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = "1";
            (entry.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.1 },
    );

    cards.forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <style>{`
        .feature-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 16px;
        }
        .feature-card {
          opacity: 0;
          transform: translateY(28px);
          transition: opacity .6s cubic-bezier(.16,1,.3,1), transform .6s cubic-bezier(.16,1,.3,1), border-color .2s ease, box-shadow .2s ease;
          border-radius: 26px;
          padding: 28px;
          border: 1px solid var(--border);
          background: ${tintedPanel};
          box-shadow: 0 18px 50px rgba(0,0,0,.05);
        }
        .feature-card:hover {
          transform: translateY(-4px) !important;
          border-color: rgba(255,77,0,.18);
          box-shadow: 0 28px 64px rgba(255,77,0,.08);
        }
        @media (max-width: 960px) {
          .feature-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 620px) {
          .feature-grid { grid-template-columns: 1fr; }
        }
      `}</style>

      <section
        id="features"
        style={{
          padding: sectionPadding,
          position: "relative",
          overflow: "hidden",
          background:
            "linear-gradient(180deg, var(--bg) 0%, color-mix(in srgb, var(--bg2) 88%, #fff3ee 12%) 100%)",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            backgroundImage:
              "radial-gradient(rgba(255,77,0,.12) 1px, transparent 1px), radial-gradient(rgba(255,77,0,.06) 1px, transparent 1px)",
            backgroundPosition: "0 0, 18px 18px",
            backgroundSize: "36px 36px",
            opacity: 0.18,
          }}
        />

        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="Features"
            title="Everything the page should communicate before your product fully ships"
            description="A sharper value story, stronger visual consistency, and cleaner architecture make the brand feel more serious without pretending the platform is already at scale."
          />

          <div ref={ref} className="feature-grid">
            {features.map(({ icon: Icon, color, tint, title, description }, index) => (
              <div
                key={title}
                className="feature-card"
                style={{ transitionDelay: `${index * 0.07}s` }}
              >
                <div
                  style={{
                    width: 54,
                    height: 54,
                    borderRadius: 18,
                    background: tint,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 18,
                  }}
                >
                  <Icon size={24} color={color} />
                </div>
                <h3
                  style={{
                    fontSize: 19,
                    lineHeight: 1.3,
                    color: "var(--text1)",
                    fontWeight: 800,
                    marginBottom: 10,
                  }}
                >
                  {title}
                </h3>
                <p style={{ fontSize: 15, lineHeight: 1.8, color: "var(--text3)" }}>
                  {description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
