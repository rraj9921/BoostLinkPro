import Link from "next/link";
import { Sparkles, Zap } from "lucide-react";
import { brandGradient, landingContainerStyle } from "../landingTheme";

const columns = [
  {
    title: "Product",
    links: [
      ["Features", "#features"],
      ["How it works", "#how"],
      ["Pricing", "#pricing"],
      ["Dashboard", "/dashboard"],
    ],
  },
  {
    title: "Company",
    links: [
      ["About", "#"],
      ["Contact", "mailto:hello@boostlinkpro.com"],
      ["Roadmap", "#"],
      ["Early access", "/auth/signup"],
    ],
  },
  {
    title: "Legal",
    links: [
      ["Privacy Policy", "/privacy"],
      ["Terms of Service", "/terms"],
      ["Data Deletion", "/data-deletion"],
    ],
  },
];

export default function Footer() {
  return (
    <>
      <style>{`
        .footer-grid {
          display: grid;
          grid-template-columns: 2fr 1fr 1fr 1fr;
          gap: 42px;
          margin-bottom: 54px;
        }
        .footer-link {
          display: block;
          padding: 4px 0;
          color: var(--text3);
          text-decoration: none;
          font-size: 14px;
          transition: color .18s ease;
        }
        .footer-link:hover { color: #FF4D00; }
        @media (max-width: 860px) {
          .footer-grid {
            grid-template-columns: 1fr 1fr;
            gap: 30px;
          }
          .footer-brand { grid-column: 1 / -1; }
        }
        @media (max-width: 540px) {
          .footer-grid { grid-template-columns: 1fr; }
        }
      `}</style>

      <footer
        style={{
          background: "var(--bg)",
          borderTop: "1px solid var(--border)",
        }}
      >
        <div style={{ ...landingContainerStyle, paddingTop: 84, paddingBottom: 48 }}>
          <div className="footer-grid">
            <div className="footer-brand">
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                <div
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: 12,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: brandGradient,
                    boxShadow: "0 10px 24px rgba(255,77,0,.18)",
                  }}
                >
                  <Zap size={16} color="white" fill="white" />
                </div>
                <span style={{ fontSize: 18, fontWeight: 800, color: "var(--text1)", letterSpacing: "-0.03em" }}>
                  BoostLink<span style={{ color: "#FF4D00" }}>Pro</span>
                </span>
              </div>

              <p
                style={{
                  maxWidth: 340,
                  fontSize: 14,
                  lineHeight: 1.78,
                  color: "var(--text3)",
                  marginBottom: 20,
                }}
              >
                A more professional landing page for an Instagram automation SaaS in
                early stage. Stronger theme, cleaner structure, and messaging that
                stays honest while the product matures.
              </p>

              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "10px 14px",
                  borderRadius: 999,
                  border: "1px solid rgba(255,77,0,.14)",
                  background: "rgba(255,77,0,.04)",
                  color: "var(--text2)",
                  fontSize: 13,
                  fontWeight: 700,
                }}
              >
                <Sparkles size={14} color="#FF4D00" />
                Built for a credible launch phase
              </div>
            </div>

            {columns.map((column) => (
              <div key={column.title}>
                <p
                  style={{
                    marginBottom: 16,
                    fontSize: 12,
                    fontWeight: 800,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    color: "var(--text1)",
                  }}
                >
                  {column.title}
                </p>
                {column.links.map(([label, href]) =>
                  href.startsWith("mailto:") ? (
                    <a key={label} href={href} className="footer-link">
                      {label}
                    </a>
                  ) : (
                    <Link key={label} href={href} className="footer-link">
                      {label}
                    </Link>
                  ),
                )}
              </div>
            ))}
          </div>

          <div
            style={{
              paddingTop: 22,
              borderTop: "1px solid var(--border)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <p style={{ fontSize: 13, color: "var(--text4)" }}>
              © 2026 BoostLink Pro. All rights reserved.
            </p>
            <p style={{ fontSize: 13, color: "var(--text4)" }}>
              Designed to evolve with the real product, not outrun it.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
