"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  Instagram,
  MessageCircle,
  Send,
  Sparkles,
  Store,
  Zap,
} from "lucide-react";
import {
  brandGradient,
  landingContainerStyle,
  tintedPanel,
} from "../landingTheme";

const launchPills = [
  "Built for creators and small businesses",
  "Official Instagram-first workflow",
  "Clean setup experience",
  "Early access is open",
];

const workflowCards = [
  {
    title: "Comment trigger",
    copy: "Choose keywords for posts, reels, and campaigns.",
    icon: MessageCircle,
    tone: "#FF4D00",
  },
  {
    title: "Instant DM",
    copy: "Send a polished reply the moment intent shows up.",
    icon: Send,
    tone: "#FF8A3D",
  },
  {
    title: "Offer delivery",
    copy: "Route people to your link, product, or booking flow.",
    icon: Store,
    tone: "#FFB347",
  },
];

const featureBullets = [
  "Keyword-based DM automation",
  "Reply flows for launches and offers",
  "Professional landing and brand feel",
  "Built to scale with your future product",
];

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    const scale = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      canvas.width = canvas.offsetWidth * scale;
      canvas.height = canvas.offsetHeight * scale;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(scale, scale);
    };

    resize();
    window.addEventListener("resize", resize);

    const dots = Array.from({ length: 44 }, () => ({
      x: Math.random() * canvas.offsetWidth,
      y: Math.random() * canvas.offsetHeight,
      vx: (Math.random() - 0.5) * 0.22,
      vy: (Math.random() - 0.5) * 0.22,
      r: Math.random() * 1.8 + 0.5,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      dots.forEach((dot) => {
        dot.x += dot.vx;
        dot.y += dot.vy;

        if (dot.x < 0 || dot.x > canvas.offsetWidth) dot.vx *= -1;
        if (dot.y < 0 || dot.y > canvas.offsetHeight) dot.vy *= -1;

        ctx.beginPath();
        ctx.arc(dot.x, dot.y, dot.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255, 94, 32, 0.24)";
        ctx.fill();
      });

      for (let i = 0; i < dots.length; i += 1) {
        for (let j = i + 1; j < dots.length; j += 1) {
          const dx = dots[i].x - dots[j].x;
          const dy = dots[i].y - dots[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 116) {
            ctx.beginPath();
            ctx.moveTo(dots[i].x, dots[i].y);
            ctx.lineTo(dots[j].x, dots[j].y);
            ctx.strokeStyle = `rgba(255, 120, 61, ${0.09 * (1 - distance / 116)})`;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }
      }

      raf = window.requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <section
      style={{
        paddingTop: 126,
        paddingBottom: 56,
        position: "relative",
        overflow: "hidden",
        background:
          "linear-gradient(180deg, #120D12 0%, #1A1016 46%, var(--bg) 100%)",
      }}
    >
      <style>{`
        .hero-shell {
          position: relative;
          z-index: 2;
          display: grid;
          grid-template-columns: minmax(0, 1.04fr) minmax(0, .96fr);
          gap: 40px;
          align-items: center;
          padding: 34px 0 68px;
        }
        .hero-copy-block,
        .hero-panel {
          min-width: 0;
          animation: heroUp .8s cubic-bezier(.16,1,.3,1) both;
        }
        .hero-panel { animation-delay: .14s; }
        .hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 10px 18px;
          border-radius: 999px;
          color: #FFD9C8;
          font-size: 13px;
          font-weight: 700;
          border: 1px solid rgba(255,255,255,.12);
          background: rgba(255,255,255,.05);
          backdrop-filter: blur(16px);
        }
        .hero-grid {
          position: absolute;
          inset: 0;
          pointer-events: none;
          background-image:
            linear-gradient(rgba(255,255,255,.045) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,.045) 1px, transparent 1px);
          background-size: 72px 72px;
          opacity: .45;
          mask-image: radial-gradient(circle at 50% 20%, black 25%, transparent 82%);
          -webkit-mask-image: radial-gradient(circle at 50% 20%, black 25%, transparent 82%);
        }
        .hero-glow {
          position: absolute;
          border-radius: 999px;
          filter: blur(90px);
          pointer-events: none;
        }
        .hero-glow.a {
          top: -170px;
          left: -80px;
          width: 420px;
          height: 420px;
          background: rgba(255,77,0,.18);
        }
        .hero-glow.b {
          top: 90px;
          right: -90px;
          width: 420px;
          height: 420px;
          background: rgba(255,84,126,.14);
        }
        .hero-glow.c {
          left: 30%;
          bottom: 140px;
          width: 320px;
          height: 320px;
          background: rgba(255,179,71,.12);
        }
        .hero-actions {
          display: flex;
          align-items: center;
          gap: 14px;
          flex-wrap: wrap;
          margin: 0 0 24px;
        }
        .hero-primary,
        .hero-secondary {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          min-height: 58px;
          padding: 0 28px;
          border-radius: 16px;
          text-decoration: none;
          font-size: 15px;
          font-weight: 800;
          transition: transform .22s cubic-bezier(.16,1,.3,1), box-shadow .22s cubic-bezier(.16,1,.3,1), border-color .2s ease;
        }
        .hero-primary {
          color: white;
          background: ${brandGradient};
          box-shadow: 0 18px 52px rgba(255,77,0,.28);
        }
        .hero-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 24px 60px rgba(255,77,0,.34);
        }
        .hero-secondary {
          color: #F7EDE8;
          border: 1px solid rgba(255,255,255,.14);
          background: rgba(255,255,255,.05);
          backdrop-filter: blur(14px);
        }
        .hero-secondary:hover {
          transform: translateY(-2px);
          border-color: rgba(255,255,255,.24);
        }
        .hero-pills {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          margin-bottom: 28px;
        }
        .hero-pill {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 14px;
          border-radius: 999px;
          background: rgba(255,255,255,.06);
          border: 1px solid rgba(255,255,255,.1);
          color: #F7E6DE;
          font-size: 13px;
          font-weight: 700;
        }
        .hero-panel-card {
          position: relative;
          overflow: hidden;
          border-radius: 30px;
          border: 1px solid rgba(255,255,255,.1);
          background: linear-gradient(180deg, rgba(28,19,25,.96) 0%, rgba(17,11,15,.98) 100%);
          box-shadow: 0 40px 110px rgba(0,0,0,.34);
        }
        .hero-panel-card::before {
          content: "";
          position: absolute;
          inset: 0;
          pointer-events: none;
          background:
            radial-gradient(circle at top right, rgba(255,77,0,.22), transparent 28%),
            radial-gradient(circle at bottom left, rgba(255,84,126,.12), transparent 34%);
        }
        .hero-panel-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 18px 20px;
          border-bottom: 1px solid rgba(255,255,255,.08);
        }
        .hero-browser-dots {
          display: flex;
          gap: 6px;
        }
        .hero-panel-flow {
          display: grid;
          gap: 14px;
          padding: 20px;
        }
        .hero-wire {
          padding: 18px;
          border-radius: 22px;
          border: 1px solid rgba(255,255,255,.08);
          background: rgba(255,255,255,.04);
          backdrop-filter: blur(14px);
        }
        .hero-workflow-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 12px;
        }
        .hero-workflow-card {
          padding: 16px;
          border-radius: 20px;
          border: 1px solid rgba(255,255,255,.08);
          background: rgba(255,255,255,.03);
        }
        .hero-foundation {
          display: grid;
          grid-template-columns: 1.15fr .85fr;
          gap: 12px;
        }
        .hero-foundation-card {
          padding: 18px;
          border-radius: 22px;
          background: rgba(255,255,255,.04);
          border: 1px solid rgba(255,255,255,.08);
        }
        .hero-feature-list {
          display: grid;
          gap: 10px;
          margin-top: 12px;
        }
        .hero-floating {
          position: absolute;
          z-index: 3;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          border-radius: 20px;
          background: rgba(22,14,18,.72);
          border: 1px solid rgba(255,255,255,.1);
          box-shadow: 0 18px 56px rgba(0,0,0,.26);
          backdrop-filter: blur(16px);
          white-space: nowrap;
        }
        .hero-floating.left {
          top: 24%;
          left: 3%;
          animation: floatA 5.2s ease-in-out infinite;
        }
        .hero-floating.right {
          right: 3%;
          bottom: 26%;
          animation: floatB 5.8s ease-in-out infinite;
        }
        .hero-curve {
          position: absolute;
          left: 0;
          right: 0;
          bottom: -2px;
          z-index: 2;
        }
        @keyframes heroUp {
          from { opacity: 0; transform: translateY(26px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes floatA {
          0%, 100% { transform: translateY(0) rotate(-1deg); }
          50% { transform: translateY(-12px) rotate(.6deg); }
        }
        @keyframes floatB {
          0%, 100% { transform: translateY(0) rotate(1deg); }
          50% { transform: translateY(-14px) rotate(-.4deg); }
        }
        @media (max-width: 1180px) {
          .hero-shell {
            grid-template-columns: 1fr;
            gap: 30px;
          }
          .hero-copy-block {
            text-align: center;
          }
          .hero-actions,
          .hero-pills {
            justify-content: center;
          }
          .hero-copy-block p {
            margin-left: auto;
            margin-right: auto;
          }
          .hero-panel {
            max-width: 820px;
            margin: 0 auto;
          }
          .hero-floating {
            display: none;
          }
        }
        @media (max-width: 760px) {
          .hero-workflow-grid,
          .hero-foundation {
            grid-template-columns: 1fr;
          }
          .hero-actions > a {
            width: 100%;
          }
          .hero-primary,
          .hero-secondary {
            width: 100%;
          }
        }
        @media (prefers-reduced-motion: reduce) {
          .hero-copy-block,
          .hero-panel,
          .hero-floating {
            animation: none !important;
          }
        }
      `}</style>

      <canvas
        ref={canvasRef}
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          pointerEvents: "none",
          zIndex: 1,
        }}
      />

      <div className="hero-grid" />
      <div className="hero-glow a" />
      <div className="hero-glow b" />
      <div className="hero-glow c" />

      <div className="hero-floating left">
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 14,
            background: "rgba(255,77,0,.14)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Instagram size={18} color="#FF7A3D" />
        </div>
        <div>
          <div style={{ fontSize: 12, color: "#FFFFFF", fontWeight: 800 }}>
            Instagram-first experience
          </div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,.62)", marginTop: 4 }}>
            Designed for DMs, launches, and conversions
          </div>
        </div>
      </div>

      <div className="hero-floating right">
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 14,
            background: "rgba(255,179,71,.14)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Sparkles size={18} color="#FFB347" />
        </div>
        <div>
          <div style={{ fontSize: 12, color: "#FFFFFF", fontWeight: 800 }}>
            Professional launch presence
          </div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,.62)", marginTop: 4 }}>
            Clear messaging now, scalable structure later
          </div>
        </div>
      </div>

      <div style={landingContainerStyle}>
        <div className="hero-shell">
          <div className="hero-copy-block">
            <div className="hero-badge">
              <Zap size={14} color="#FFB347" />
              Pre-launch Instagram automation platform
            </div>

            <h1
              style={{
                marginTop: 24,
                marginBottom: 22,
                fontSize: "clamp(46px, 7vw, 90px)",
                lineHeight: 0.95,
                letterSpacing: "-0.055em",
                color: "#FFFFFF",
                fontWeight: 800,
                maxWidth: 760,
              }}
            >
              Make your Instagram
              <span
                style={{
                  display: "block",
                  marginTop: 12,
                  background: brandGradient,
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                automation brand feel premium from day one
              </span>
            </h1>

            <p
              style={{
                fontSize: "clamp(17px, 2vw, 21px)",
                lineHeight: 1.78,
                color: "rgba(255,255,255,.74)",
                maxWidth: 620,
                marginBottom: 28,
              }}
            >
              Build a polished SaaS presence for creators, coaches, and businesses who
              want to turn comments into conversations, DMs into intent, and Instagram
              traffic into real opportunities.
            </p>

            <div className="hero-actions">
              <Link href="/auth/signup" className="hero-primary">
                Join early access <ArrowRight size={18} />
              </Link>
              <a href="#how" className="hero-secondary">
                See the workflow
              </a>
            </div>

            <div className="hero-pills">
              {launchPills.map((pill) => (
                <span key={pill} className="hero-pill">
                  <CheckCircle2 size={14} color="#FFB347" />
                  {pill}
                </span>
              ))}
            </div>
          </div>

          <div className="hero-panel">
            <div className="hero-panel-card">
              <div className="hero-panel-top">
                <div className="hero-browser-dots">
                  {["#FF5F57", "#FEBC2E", "#28C840"].map((color) => (
                    <span
                      key={color}
                      style={{
                        width: 11,
                        height: 11,
                        borderRadius: "50%",
                        background: color,
                        display: "inline-block",
                      }}
                    />
                  ))}
                </div>
                <div
                  style={{
                    borderRadius: 999,
                    padding: "8px 12px",
                    fontSize: 11,
                    fontWeight: 800,
                    color: "#FFD8C6",
                    background: "rgba(255,255,255,.05)",
                    border: "1px solid rgba(255,255,255,.08)",
                  }}
                >
                  Launch-ready product story
                </div>
              </div>

              <div className="hero-panel-flow">
                <div
                  className="hero-wire"
                  style={{
                    background: tintedPanel,
                    color: "var(--text1)",
                    border: "1px solid rgba(255,255,255,.08)",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: 12,
                      marginBottom: 14,
                    }}
                  >
                    <div>
                      <p style={{ fontSize: 12, fontWeight: 800, color: "var(--text3)" }}>
                        Product positioning
                      </p>
                      <h3
                        style={{
                          fontSize: 22,
                          lineHeight: 1.15,
                          fontWeight: 800,
                          color: "var(--text1)",
                          marginTop: 6,
                        }}
                      >
                        Instagram comment-to-DM automation for modern sellers
                      </h3>
                    </div>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 800,
                        color: "#FF4D00",
                        background: "rgba(255,77,0,.08)",
                        borderRadius: 999,
                        padding: "6px 10px",
                      }}
                    >
                      Clear value
                    </span>
                  </div>
                  <p
                    style={{
                      fontSize: 14,
                      lineHeight: 1.7,
                      color: "var(--text2)",
                    }}
                  >
                    No fake revenue, no inflated growth claims, and no noisy dashboard
                    tricks. Just a confident product story built around automation,
                    speed, and trust.
                  </p>
                </div>

                <div className="hero-workflow-grid">
                  {workflowCards.map(({ title, copy, icon: Icon, tone }) => (
                    <div key={title} className="hero-workflow-card">
                      <div
                        style={{
                          width: 44,
                          height: 44,
                          borderRadius: 16,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          background: `${tone}18`,
                          marginBottom: 14,
                        }}
                      >
                        <Icon size={18} color={tone} />
                      </div>
                      <div style={{ color: "#FFFFFF", fontWeight: 800, fontSize: 15, marginBottom: 8 }}>
                        {title}
                      </div>
                      <div style={{ color: "rgba(255,255,255,.64)", fontSize: 13, lineHeight: 1.65 }}>
                        {copy}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="hero-foundation">
                  <div className="hero-foundation-card">
                    <div style={{ fontSize: 12, fontWeight: 800, color: "rgba(255,255,255,.58)" }}>
                      Why this landing page works
                    </div>
                    <div className="hero-feature-list">
                      {featureBullets.map((feature) => (
                        <div
                          key={feature}
                          style={{
                            display: "flex",
                            alignItems: "flex-start",
                            gap: 10,
                            color: "#F8ECE6",
                            fontSize: 14,
                            lineHeight: 1.6,
                          }}
                        >
                          <CheckCircle2 size={16} color="#FFB347" style={{ flexShrink: 0, marginTop: 3 }} />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="hero-foundation-card">
                    <div style={{ fontSize: 12, fontWeight: 800, color: "rgba(255,255,255,.58)" }}>
                      Pre-launch positioning
                    </div>
                    <div
                      style={{
                        marginTop: 12,
                        fontSize: 14,
                        lineHeight: 1.7,
                        color: "rgba(255,255,255,.72)",
                      }}
                    >
                      Present the platform as thoughtfully designed, product-led, and
                      ready for early adopters without pretending the roadmap is already
                      complete.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="hero-curve">
        <svg
          viewBox="0 0 1440 90"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          style={{ display: "block", width: "100%", height: 90 }}
        >
          <path
            d="M0 18C136 31 271 50 425 58C601 67 793 64 958 54C1146 42 1308 18 1440 6V90H0V18Z"
            fill="var(--bg)"
          />
        </svg>
      </div>
    </section>
  );
}
