"use client";

import { useEffect, useRef } from "react";
import { ArrowRight, Instagram, MessageCircleMore, Send } from "lucide-react";
import SectionIntro from "../SectionIntro";
import { landingContainerStyle, sectionPadding, tintedPanel } from "../landingTheme";

const steps = [
  {
    id: "01",
    title: "Connect your Instagram brand",
    description:
      "Start with the product promise: who this is for, what it automates, and why the workflow matters inside Instagram.",
    icon: Instagram,
    color: "#FF4D00",
    tint: "rgba(255,77,0,.1)",
  },
  {
    id: "02",
    title: "Define the message flow",
    description:
      "Map how a comment turns into a DM, a DM turns into a next step, and the next step leads to a product, booking, or offer.",
    icon: MessageCircleMore,
    color: "#FF8A3D",
    tint: "rgba(255,138,61,.1)",
  },
  {
    id: "03",
    title: "Launch with clarity",
    description:
      "Use a confident landing page now, then layer in real dashboard screenshots, analytics, and customer proof when the product is ready.",
    icon: Send,
    color: "#FFB347",
    tint: "rgba(255,179,71,.12)",
  },
];

export default function HowItWorks() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cards = ref.current?.querySelectorAll(".step-card");
    if (!cards) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = "1";
            (entry.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.12 },
    );

    cards.forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <style>{`
        .steps-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 18px;
          margin-bottom: 28px;
        }
        .step-card {
          opacity: 0;
          transform: translateY(28px);
          transition: opacity .6s cubic-bezier(.16,1,.3,1), transform .6s cubic-bezier(.16,1,.3,1), box-shadow .2s ease, border-color .2s ease;
          position: relative;
          border-radius: 28px;
          padding: 30px 26px;
          border: 1px solid var(--border);
          background: ${tintedPanel};
          box-shadow: 0 20px 52px rgba(0,0,0,.05);
        }
        .step-card:hover {
          transform: translateY(-4px) !important;
          border-color: rgba(255,77,0,.18);
          box-shadow: 0 28px 64px rgba(255,77,0,.08);
        }
        .scenario-card {
          border-radius: 30px;
          border: 1px solid var(--border);
          background: linear-gradient(180deg, color-mix(in srgb, var(--card) 96%, transparent), color-mix(in srgb, var(--bg2) 90%, #fff6f1 10%));
          padding: 32px;
          box-shadow: 0 24px 64px rgba(255,77,0,.08);
        }
        .scenario-grid {
          display: grid;
          grid-template-columns: 1fr auto 1fr;
          gap: 20px;
          align-items: center;
        }
        @media (max-width: 920px) {
          .steps-grid { grid-template-columns: 1fr; }
          .scenario-grid { grid-template-columns: 1fr; }
        }
      `}</style>

      <section
        id="how"
        style={{
          padding: sectionPadding,
          background: "var(--bg)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            backgroundImage: "radial-gradient(var(--border2) 1px, transparent 1px)",
            backgroundSize: "28px 28px",
            opacity: 0.32,
          }}
        />

        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="How it works"
            title="A better story for a platform that is still taking shape"
            description="This version explains the product in a way that feels strategic and complete, while staying honest about where the platform is today."
          />

          <div ref={ref} className="steps-grid">
            {steps.map(({ id, title, description, icon: Icon, color, tint }, index) => (
              <div
                key={id}
                className="step-card"
                style={{ transitionDelay: `${index * 0.08}s` }}
              >
                <div
                  style={{
                    position: "absolute",
                    top: 18,
                    right: 18,
                    fontSize: 42,
                    fontWeight: 800,
                    lineHeight: 1,
                    color: "rgba(255,77,0,.08)",
                  }}
                >
                  {id}
                </div>
                <div
                  style={{
                    width: 58,
                    height: 58,
                    borderRadius: 18,
                    background: tint,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 18,
                  }}
                >
                  <Icon size={24} color={color} />
                </div>
                <h3
                  style={{
                    fontSize: 20,
                    fontWeight: 800,
                    lineHeight: 1.28,
                    color: "var(--text1)",
                    marginBottom: 12,
                    maxWidth: 260,
                  }}
                >
                  {title}
                </h3>
                <p style={{ fontSize: 15, lineHeight: 1.78, color: "var(--text3)" }}>
                  {description}
                </p>
              </div>
            ))}
          </div>

          <div className="scenario-card">
            <p
              style={{
                fontSize: 11,
                fontWeight: 800,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                color: "#FF4D00",
                marginBottom: 24,
                textAlign: "center",
              }}
            >
              Example flow
            </p>

            <div className="scenario-grid">
              <div
                style={{
                  padding: "18px 20px",
                  borderRadius: 22,
                  border: "1px solid var(--border)",
                  background: "var(--card)",
                }}
              >
                <p style={{ fontSize: 12, fontWeight: 800, color: "var(--text3)", marginBottom: 8 }}>
                  Someone comments on your post
                </p>
                <p style={{ fontSize: 15, lineHeight: 1.7, color: "var(--text2)" }}>
                  “Can you send me the details?”
                </p>
              </div>

              <div style={{ textAlign: "center" }}>
                <div
                  style={{
                    width: 54,
                    height: 54,
                    borderRadius: "50%",
                    margin: "0 auto 10px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "rgba(255,77,0,.08)",
                    border: "1px solid rgba(255,77,0,.18)",
                  }}
                >
                  <ArrowRight size={18} color="#FF4D00" />
                </div>
                <p style={{ fontSize: 11, color: "#FF4D00", fontWeight: 800, letterSpacing: "0.08em" }}>
                  AUTOMATION
                </p>
              </div>

              <div
                style={{
                  padding: "18px 20px",
                  borderRadius: 22,
                  border: "1px solid rgba(255,77,0,.18)",
                  background: "linear-gradient(180deg, rgba(255,77,0,.06), rgba(255,179,71,.1))",
                }}
              >
                <p style={{ fontSize: 12, fontWeight: 800, color: "#C94D0B", marginBottom: 8 }}>
                  They receive a clean DM
                </p>
                <p style={{ fontSize: 15, lineHeight: 1.7, color: "var(--text2)" }}>
                  A polished message with your next step, whether that is a product
                  link, booking link, waitlist, or offer page.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
