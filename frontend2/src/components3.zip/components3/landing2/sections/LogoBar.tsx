import { landingContainerStyle } from "../landingTheme";

const badges = [
  "Instagram-first automation",
  "Keyword-based triggers",
  "DM-led sales journeys",
  "Launch-ready positioning",
  "Built for creators",
  "Future-proof design system",
  "Clean onboarding experience",
  "Professional brand presence",
];

export default function LogoBar() {
  return (
    <>
      <style>{`
        .lb-track {
          display: flex;
          gap: 12px;
          width: max-content;
          animation: lbScroll 28s linear infinite;
        }
        .lb-track:hover { animation-play-state: paused; }
        .lb-chip {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 12px 18px;
          border-radius: 999px;
          border: 1px solid rgba(255,77,0,.12);
          background: linear-gradient(180deg, rgba(255,255,255,.9), rgba(255,248,244,.96));
          white-space: nowrap;
          box-shadow: 0 12px 30px rgba(255,77,0,.06);
        }
        @keyframes lbScroll {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>

      <section
        style={{
          background: "var(--bg)",
          padding: "30px 0 10px",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: "0 0 auto 0",
            height: 1,
            background: "linear-gradient(90deg, transparent, rgba(255,77,0,.18), transparent)",
          }}
        />
        <div style={landingContainerStyle}>
          <p
            style={{
              textAlign: "center",
              fontSize: 11,
              fontWeight: 800,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "var(--text4)",
              marginBottom: 18,
            }}
          >
            Designed for a serious SaaS launch, not a placeholder landing page
          </p>
          <div className="lb-track">
            {[...badges, ...badges].map((badge, index) => (
              <div key={`${badge}-${index}`} className="lb-chip">
                <span
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background: "linear-gradient(135deg,#FF4D00,#FFB347)",
                    display: "inline-block",
                  }}
                />
                <span style={{ fontSize: 13, color: "var(--text2)", fontWeight: 700 }}>
                  {badge}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
