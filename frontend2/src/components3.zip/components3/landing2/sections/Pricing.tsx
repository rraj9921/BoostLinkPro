"use client";

import Link from "next/link";
import { ArrowRight, Check, Sparkles } from "lucide-react";
import { useEffect, useRef } from "react";
import SectionIntro from "../SectionIntro";
import {
  brandGradient,
  darkPanel,
  landingContainerStyle,
  sectionPadding,
} from "../landingTheme";

const plans = [
  {
    name: "Early Access",
    title: "Join the first product wave",
    description:
      "Perfect if you want to watch the platform evolve, get access early, and shape the product direction.",
    cta: "Join waitlist",
    features: [
      "Access to launch updates",
      "Early onboarding invites",
      "Founding-user communication",
      "Product feedback opportunities",
    ],
  },
  {
    name: "Founding",
    title: "For serious early adopters",
    description:
      "For creators and businesses who want a stronger relationship with the product as it moves toward launch.",
    cta: "Request founding access",
    featured: true,
    badge: "Recommended",
    features: [
      "Priority early-access review",
      "Closer product feedback loop",
      "Future pricing preference at launch",
      "First access to new automation flows",
    ],
  },
  {
    name: "Launch Team",
    title: "For brand and rollout partners",
    description:
      "Best for teams who want to collaborate around onboarding, rollout quality, and future platform fit.",
    cta: "Talk to us",
    href: "mailto:hello@boostlinkpro.com",
    features: [
      "Custom onboarding conversation",
      "Use-case discovery",
      "Feedback-driven rollout planning",
      "Longer-term product alignment",
    ],
  },
];

export default function Pricing() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cards = ref.current?.querySelectorAll(".price-card");
    if (!cards) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = "1";
            (entry.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.1 },
    );

    cards.forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <style>{`
        .pricing-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 18px;
          align-items: stretch;
        }
        .price-card {
          opacity: 0;
          transform: translateY(28px);
          transition: opacity .6s cubic-bezier(.16,1,.3,1), transform .6s cubic-bezier(.16,1,.3,1), border-color .2s ease, box-shadow .2s ease;
          position: relative;
          display: flex;
          flex-direction: column;
          min-height: 100%;
          border-radius: 28px;
          padding: 30px;
          background: rgba(255,255,255,.05);
          border: 1px solid rgba(255,255,255,.1);
          backdrop-filter: blur(18px);
        }
        .price-card.featured {
          background: linear-gradient(180deg, rgba(255,255,255,.09), rgba(255,255,255,.04));
          border-color: rgba(255,122,61,.26);
          box-shadow: 0 30px 80px rgba(255,77,0,.18);
        }
        .price-card:hover {
          transform: translateY(-4px) !important;
          border-color: rgba(255,122,61,.26);
        }
        @media (max-width: 960px) {
          .pricing-grid {
            grid-template-columns: 1fr;
            max-width: 520px;
            margin: 0 auto;
          }
        }
      `}</style>

      <section
        id="pricing"
        style={{
          padding: sectionPadding,
          position: "relative",
          overflow: "hidden",
          background: darkPanel,
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            background:
              "radial-gradient(circle at 22% 10%, rgba(255,77,0,.18), transparent 22%), radial-gradient(circle at 80% 56%, rgba(255,84,126,.12), transparent 28%)",
          }}
        />

        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="Pricing"
            title="Replace fake pricing with honest launch-stage options"
            description="Since the product has not started yet, this section now feels strategic instead of misleading. It still looks premium, but it no longer pretends the final business model is locked."
            titleStyle={{ color: "white", maxWidth: 760, marginLeft: "auto", marginRight: "auto" }}
            descriptionStyle={{ color: "rgba(255,255,255,.72)", maxWidth: 700 }}
          />

          <div ref={ref} className="pricing-grid">
            {plans.map((plan, index) => (
              <div
                key={plan.name}
                className={`price-card${plan.featured ? " featured" : ""}`}
                style={{ transitionDelay: `${index * 0.08}s` }}
              >
                {plan.badge && (
                  <div
                    style={{
                      position: "absolute",
                      top: -14,
                      left: 26,
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 8,
                      padding: "7px 14px",
                      borderRadius: 999,
                      background: brandGradient,
                      color: "white",
                      fontSize: 11,
                      fontWeight: 800,
                      letterSpacing: "0.08em",
                      textTransform: "uppercase",
                    }}
                  >
                    <Sparkles size={12} />
                    {plan.badge}
                  </div>
                )}

                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 800,
                    letterSpacing: "0.14em",
                    textTransform: "uppercase",
                    color: plan.featured ? "#FFD7C8" : "rgba(255,255,255,.56)",
                    marginBottom: 12,
                  }}
                >
                  {plan.name}
                </div>

                <h3 style={{ fontSize: 28, lineHeight: 1.1, color: "white", fontWeight: 800, marginBottom: 12 }}>
                  {plan.title}
                </h3>

                <p style={{ fontSize: 15, lineHeight: 1.78, color: "rgba(255,255,255,.7)", marginBottom: 24 }}>
                  {plan.description}
                </p>

                <ul
                  style={{
                    listStyle: "none",
                    display: "grid",
                    gap: 12,
                    marginBottom: 28,
                    flex: 1,
                  }}
                >
                  {plan.features.map((feature) => (
                    <li
                      key={feature}
                      style={{
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 12,
                        color: "rgba(255,255,255,.82)",
                        fontSize: 14,
                        lineHeight: 1.55,
                      }}
                    >
                      <span
                        style={{
                          width: 22,
                          height: 22,
                          borderRadius: "50%",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          background: "rgba(255,122,61,.12)",
                          flexShrink: 0,
                        }}
                      >
                        <Check size={12} color="#FFB347" />
                      </span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                {plan.href ? (
                  <a
                    href={plan.href}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 10,
                      minHeight: 56,
                      borderRadius: 16,
                      textDecoration: "none",
                      fontSize: 15,
                      fontWeight: 800,
                      color: plan.featured ? "#1C1116" : "white",
                      background: plan.featured ? "white" : brandGradient,
                      boxShadow: plan.featured
                        ? "0 14px 38px rgba(255,255,255,.14)"
                        : "0 18px 46px rgba(255,77,0,.24)",
                    }}
                  >
                    {plan.cta} <ArrowRight size={16} />
                  </a>
                ) : (
                  <Link
                    href="/auth/signup"
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 10,
                      minHeight: 56,
                      borderRadius: 16,
                      textDecoration: "none",
                      fontSize: 15,
                      fontWeight: 800,
                      color: plan.featured ? "#1C1116" : "white",
                      background: plan.featured ? "white" : brandGradient,
                      boxShadow: plan.featured
                        ? "0 14px 38px rgba(255,255,255,.14)"
                        : "0 18px 46px rgba(255,77,0,.24)",
                    }}
                  >
                    {plan.cta} <ArrowRight size={16} />
                  </Link>
                )}
              </div>
            ))}
          </div>

          <p
            style={{
              marginTop: 24,
              textAlign: "center",
              fontSize: 14,
              lineHeight: 1.7,
              color: "rgba(255,255,255,.56)",
            }}
          >
            Final feature limits and commercial pricing can be published later, once the
            platform is actually ready to sell.
          </p>
        </div>
      </section>
    </>
  );
}
