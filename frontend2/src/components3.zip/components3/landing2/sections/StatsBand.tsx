"use client";

import { useEffect, useRef } from "react";
import { Blocks, Lock, MessageSquareShare, Palette } from "lucide-react";
import SectionIntro from "../SectionIntro";
import { darkPanel, landingContainerStyle, sectionPadding } from "../landingTheme";

const trustCards = [
  {
    icon: MessageSquareShare,
    title: "Built around Instagram intent",
    description:
      "The messaging now emphasizes comment-driven automation and DM conversion flows instead of generic growth-tool language.",
  },
  {
    icon: Palette,
    title: "A stronger visual identity",
    description:
      "The new red-black system brings a more premium product look, inspired by your reference but adapted to your actual brand context.",
  },
  {
    icon: Blocks,
    title: "Reusable by design",
    description:
      "Shared heading styles and centralized landing tokens make future edits easier when you add real screenshots, pricing, and proof.",
  },
  {
    icon: Lock,
    title: "Honest product communication",
    description:
      "Nothing here depends on fake metrics or invented customer outcomes, so the page can grow with the product without feeling misleading.",
  },
];

export default function StatsBand() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cards = ref.current?.querySelectorAll(".trust-card");
    if (!cards) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = "1";
            (entry.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.1 },
    );

    cards.forEach((card) => observer.observe(card));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <style>{`
        .trust-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 14px;
        }
        .trust-card {
          opacity: 0;
          transform: translateY(24px);
          transition: opacity .55s cubic-bezier(.16,1,.3,1), transform .55s cubic-bezier(.16,1,.3,1), border-color .2s ease, background .2s ease;
          padding: 28px 24px;
          border-radius: 26px;
          background: rgba(255,255,255,.05);
          border: 1px solid rgba(255,255,255,.1);
          backdrop-filter: blur(18px);
        }
        .trust-card:hover {
          border-color: rgba(255,122,61,.24);
          background: rgba(255,255,255,.07);
        }
        @media (max-width: 980px) {
          .trust-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 580px) {
          .trust-grid { grid-template-columns: 1fr; }
        }
      `}</style>

      <section
        style={{
          padding: sectionPadding,
          position: "relative",
          overflow: "hidden",
          background: darkPanel,
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            background:
              "radial-gradient(circle at 20% 20%, rgba(255,77,0,.2), transparent 22%), radial-gradient(circle at 86% 50%, rgba(255,84,126,.14), transparent 26%)",
          }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            backgroundImage: "radial-gradient(rgba(255,255,255,.12) 1px, transparent 1px)",
            backgroundSize: "24px 24px",
            opacity: 0.12,
          }}
        />

        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="Why this direction works"
            title="A more premium SaaS look with a more believable product voice"
            description="The page now feels intentional, modern, and investor-safe without promising analytics, customer results, or feature depth you do not have yet."
            titleStyle={{ color: "white", maxWidth: 760, marginLeft: "auto", marginRight: "auto" }}
            descriptionStyle={{ color: "rgba(255,255,255,.72)", maxWidth: 700 }}
          />

          <div ref={ref} className="trust-grid">
            {trustCards.map(({ icon: Icon, title, description }, index) => (
              <div
                key={title}
                className="trust-card"
                style={{ transitionDelay: `${index * 0.07}s` }}
              >
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 18,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "rgba(255,122,61,.14)",
                    marginBottom: 16,
                  }}
                >
                  <Icon size={22} color="#FFB347" />
                </div>
                <h3 style={{ fontSize: 18, fontWeight: 800, color: "white", marginBottom: 10, lineHeight: 1.3 }}>
                  {title}
                </h3>
                <p style={{ fontSize: 14, lineHeight: 1.75, color: "rgba(255,255,255,.68)" }}>
                  {description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
