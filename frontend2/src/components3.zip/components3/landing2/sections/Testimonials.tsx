"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { useEffect, useRef } from "react";
import SectionIntro from "../SectionIntro";
import { brandGradient, brandGlow, landingContainerStyle, sectionPadding, tintedPanel } from "../landingTheme";

const faqs = [
  {
    question: "Why does the site avoid customer counts and revenue claims?",
    answer:
      "Because the product is still early. It is better to communicate the product vision clearly now and add proof later when that proof is real.",
  },
  {
    question: "Can this still feel premium without real screenshots?",
    answer:
      "Yes. Strong hierarchy, clear positioning, and believable product framing do more for trust than fake dashboards ever will.",
  },
  {
    question: "Will this design scale as the SaaS grows?",
    answer:
      "Yes. The shared tokens and repeated layout patterns make it much easier to add future sections, proof blocks, and product details.",
  },
  {
    question: "Does the copy speak to Instagram automation specifically?",
    answer:
      "Yes. The new messaging is anchored around comment triggers, DMs, launches, creator offers, and Instagram-native workflows.",
  },
  {
    question: "Can pricing stay on the page before launch?",
    answer:
      "Yes, but it should be framed as launch planning or early-access tiers instead of pretending final commercial plans are already locked in.",
  },
  {
    question: "Is the page reusable beyond this first launch phase?",
    answer:
      "Yes. It now acts as a brand system you can keep evolving, rather than a one-off landing page that will need a full rewrite later.",
  },
];

export default function Testimonials() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const items = ref.current?.querySelectorAll(".faq-card");
    if (!items) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = "1";
            (entry.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.08 },
    );

    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <style>{`
        .faq-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 14px;
          margin-bottom: 54px;
        }
        .faq-card {
          opacity: 0;
          transform: translateY(24px);
          transition: opacity .55s cubic-bezier(.16,1,.3,1), transform .55s cubic-bezier(.16,1,.3,1), border-color .2s ease, box-shadow .2s ease;
          padding: 26px;
          border-radius: 24px;
          border: 1px solid var(--border);
          background: ${tintedPanel};
        }
        .faq-card:hover {
          transform: translateY(-4px) !important;
          border-color: rgba(255,77,0,.18);
          box-shadow: 0 24px 58px rgba(255,77,0,.08);
        }
        @media (max-width: 960px) {
          .faq-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 620px) {
          .faq-grid { grid-template-columns: 1fr; }
        }
      `}</style>

      <section
        style={{
          padding: sectionPadding,
          position: "relative",
          overflow: "hidden",
          background: "var(--bg)",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            background:
              "radial-gradient(circle at 88% 14%, rgba(255,77,0,.08), transparent 20%), linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)",
            backgroundSize: "auto, 64px 64px, 64px 64px",
            opacity: 0.38,
          }}
        />

        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="Questions"
            title="Professional, attractive, and still honest"
            description="These answers reinforce the tone of the page: intentional product thinking, clear positioning, and no pressure to invent traction before you have it."
          />

          <div ref={ref} className="faq-grid">
            {faqs.map((faq, index) => (
              <div
                key={faq.question}
                className="faq-card"
                style={{ transitionDelay: `${index * 0.06}s` }}
              >
                <div
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 14,
                    background: "rgba(255,77,0,.08)",
                    color: "#FF4D00",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 18,
                    fontWeight: 800,
                    marginBottom: 14,
                  }}
                >
                  ?
                </div>
                <h3 style={{ fontSize: 17, fontWeight: 800, color: "var(--text1)", marginBottom: 10, lineHeight: 1.4 }}>
                  {faq.question}
                </h3>
                <p style={{ fontSize: 15, color: "var(--text3)", lineHeight: 1.78 }}>
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>

          <div style={{ textAlign: "center" }}>
            <Link
              href="/auth/signup"
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 10,
                minHeight: 58,
                padding: "0 30px",
                borderRadius: 16,
                textDecoration: "none",
                color: "white",
                background: brandGradient,
                fontSize: 16,
                fontWeight: 800,
                boxShadow: brandGlow,
              }}
            >
              Join early access <ArrowRight size={17} />
            </Link>
            <p style={{ marginTop: 14, fontSize: 14, color: "var(--text3)" }}>
              Built to look credible today and scale cleanly later
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
