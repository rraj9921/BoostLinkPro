"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, Rocket, Sparkles, X } from "lucide-react";
import ThemeToggle from "../theme/ThemeToggle";
import { brandGradient } from "./landingTheme";

const navLinks = [
  ["Features", "#features"],
  ["How it works", "#how"],
  ["Pricing", "#pricing"],
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 18);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <style>{`
        .nav-links,
        .nav-actions {
          display: flex;
          align-items: center;
        }
        .nav-links { gap: 34px; }
        .nav-actions { gap: 10px; }
        .nav-mobile { display: none !important; }
        .nav-link {
          position: relative;
          color: rgba(255,255,255,.78);
          font-size: 15px;
          font-weight: 700;
          text-decoration: none;
          transition: color .18s ease;
        }
        .nav-link::after {
          content: "";
          position: absolute;
          left: 0;
          right: 0;
          bottom: -8px;
          height: 2px;
          border-radius: 999px;
          background: linear-gradient(90deg, #FF4D00, #FFB347);
          opacity: 0;
          transform: scaleX(.6);
          transition: opacity .18s ease, transform .18s ease;
        }
        .nav-link:hover {
          color: white;
        }
        .nav-link:hover::after {
          opacity: 1;
          transform: scaleX(1);
        }
        .nav-login {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 42px;
          padding: 0 14px;
          border-radius: 12px;
          color: rgba(255,255,255,.84);
          text-decoration: none;
          font-size: 14px;
          font-weight: 700;
          border: 1px solid rgba(255,255,255,.1);
          background: rgba(255,255,255,.04);
          transition: border-color .18s ease, color .18s ease, background .18s ease;
        }
        .nav-login:hover {
          color: white;
          border-color: rgba(255,255,255,.18);
          background: rgba(255,255,255,.07);
        }
        .nav-cta {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          min-height: 44px;
          padding: 0 18px;
          border-radius: 12px;
          text-decoration: none;
          font-size: 14px;
          font-weight: 800;
          color: white;
          background: ${brandGradient};
          box-shadow: 0 14px 34px rgba(255,77,0,.28);
          transition: transform .2s ease, box-shadow .2s ease;
        }
        .nav-cta:hover {
          transform: translateY(-1px);
          box-shadow: 0 18px 42px rgba(255,77,0,.34);
        }
        .brand-lockup {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }
        .brand-mark {
          position: relative;
          width: 44px;
          height: 44px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(180deg, rgba(255,255,255,.12), rgba(255,255,255,.05));
          border: 1px solid rgba(255,255,255,.12);
          box-shadow: 0 12px 28px rgba(0,0,0,.18);
          overflow: hidden;
          flex-shrink: 0;
        }
        .brand-mark::before {
          content: "";
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 20% 15%, rgba(255,255,255,.18), transparent 36%);
          pointer-events: none;
        }
        .brand-copy {
          display: flex;
          flex-direction: column;
          min-width: 0;
        }
        .brand-name {
          font-size: 29px;
          line-height: .92;
          font-weight: 900;
          letter-spacing: -.06em;
          color: white;
          white-space: nowrap;
        }
        .brand-pro {
          color: #FF7A3D;
        }
        .brand-tag {
          font-size: 10px;
          letter-spacing: .14em;
          text-transform: uppercase;
          color: rgba(255,255,255,.5);
          font-weight: 800;
          margin-top: 4px;
          white-space: nowrap;
        }
        @media (max-width: 960px) {
          .nav-links,
          .nav-actions { display: none !important; }
          .nav-mobile { display: flex !important; align-items: center; gap: 8px; }
          .brand-name { font-size: 25px; }
        }
        @media (max-width: 520px) {
          .brand-tag { display: none; }
          .brand-name { font-size: 22px; }
          .brand-mark {
            width: 40px;
            height: 40px;
          }
        }
      `}</style>

      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          borderBottom: scrolled
            ? "1px solid rgba(255,255,255,.08)"
            : "1px solid transparent",
          background: scrolled
            ? "linear-gradient(180deg, rgba(14,10,13,.88), rgba(18,12,16,.8))"
            : "linear-gradient(180deg, rgba(10,8,10,.42), rgba(10,8,10,.18))",
          backdropFilter: "blur(26px) saturate(165%)",
          WebkitBackdropFilter: "blur(26px) saturate(165%)",
          boxShadow: scrolled ? "0 10px 36px rgba(0,0,0,.18)" : "none",
          transition: "all .28s cubic-bezier(.16,1,.3,1)",
        }}
      >
        <div
          style={{
            width: "100%",
            maxWidth: "none",
            padding: "0 clamp(20px, 3vw, 42px)",
            height: 78,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Link
            href="/"
            style={{
              textDecoration: "none",
              minWidth: 0,
            }}
          >
            <div className="brand-lockup">
              <div className="brand-mark">
                <Rocket
                  size={20}
                  color="#FF7A3D"
                  fill="#FF7A3D"
                  style={{ transform: "rotate(-20deg)" }}
                />
              </div>
              <div className="brand-copy">
                <span className="brand-name">
                  Boostlink<span className="brand-pro">pro</span>
                </span>
                <span className="brand-tag">Instagram automation platform</span>
              </div>
            </div>
          </Link>

          <div className="nav-links">
            {navLinks.map(([label, href]) => (
              <a key={label} href={href} className="nav-link">
                {label}
              </a>
            ))}
          </div>

          <div className="nav-actions">
            <ThemeToggle />
            <Link href="/auth/login" className="nav-login">
              Sign in
            </Link>
            <Link href="/auth/signup" className="nav-cta">
              <Sparkles size={14} />
              Join early access
            </Link>
          </div>

          <div className="nav-mobile">
            <ThemeToggle />
            <button
              onClick={() => setOpen((value) => !value)}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                width: 42,
                height: 42,
                borderRadius: 12,
                border: "1px solid rgba(255,255,255,.1)",
                background: "rgba(255,255,255,.05)",
                color: "white",
                cursor: "pointer",
              }}
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {open && (
          <div
            style={{
              background: "linear-gradient(180deg, rgba(16,10,14,.96), rgba(12,8,11,.98))",
              borderTop: "1px solid rgba(255,255,255,.08)",
              padding: "18px 28px 28px",
              boxShadow: "0 20px 42px rgba(0,0,0,.18)",
            }}
          >
            {navLinks.map(([label, href]) => (
              <a
                key={label}
                href={href}
                onClick={() => setOpen(false)}
                style={{
                  display: "block",
                  padding: "14px 0",
                  fontSize: 16,
                  fontWeight: 700,
                  color: "rgba(255,255,255,.84)",
                  textDecoration: "none",
                  borderBottom: "1px solid rgba(255,255,255,.08)",
                }}
              >
                {label}
              </a>
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
              <Link
                href="/auth/login"
                onClick={() => setOpen(false)}
                className="nav-login"
                style={{ flex: 1 }}
              >
                Sign in
              </Link>
              <Link
                href="/auth/signup"
                onClick={() => setOpen(false)}
                className="nav-cta"
                style={{ flex: 1 }}
              >
                Join access
              </Link>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
