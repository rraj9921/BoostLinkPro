"use client";
import { useEffect, useRef } from "react";
import {
  BarChart2,
  Link2,
  MessageCircle,
  ShoppingBag,
  Users,
  Zap,
} from "lucide-react";
import SectionIntro from "../SectionIntro";
import { landingContainerStyle, sectionPadding } from "../landingTheme";

const features = [
  {
    icon: MessageCircle,
    color: "#FF4D00",
    tint: "rgba(255,77,0,.1)",
    title: "Comment-to-DM automation",
    description:
      "Set a keyword on any post or reel. Every time someone comments it, they instantly receive your personalised DM — automatically, with no manual work ever.",
    big: true,
  },
  {
    icon: ShoppingBag,
    color: "#10B981",
    tint: "rgba(16,185,129,.1)",
    title: "Sell digital products",
    description:
      "Upload your PDF, course, or template. Buyers pay via Stripe and receive their download link automatically — zero manual delivery.",
    tag: "Most popular",
  },
  {
    icon: Link2,
    color: "#0EA5E9",
    tint: "rgba(14,165,233,.1)",
    title: "Link-in-bio store",
    description:
      "Your own page at boostlinkpro.com/yourname — all your products, links, and offers in one URL perfect for your Instagram bio.",
  },
  {
    icon: Zap,
    color: "#8B5CF6",
    tint: "rgba(139,92,246,.1)",
    title: "Auto-reply to comments",
    description:
      "Post a public reply on every matched comment before the DM goes out — more engagement signals, zero manual effort.",
  },
  {
    icon: Users,
    color: "#F43F5E",
    tint: "rgba(244,63,94,.1)",
    title: "Followers-only mode",
    description:
      "Optionally restrict automations to followers only — ideal for exclusive drops and early-access launches.",
  },
  {
    icon: BarChart2,
    color: "#F59E0B",
    tint: "rgba(245,158,11,.1)",
    title: "Analytics dashboard",
    description:
      "See which keywords drive the most DMs, which products convert, and how your bio link performs — all in one place.",
  },
];

export default function Features() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const cards = ref.current?.querySelectorAll(".fc");
    if (!cards) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            (e.target as HTMLElement).style.opacity = "1";
            (e.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.08 },
    );
    cards.forEach((c) => obs.observe(c));
    return () => obs.disconnect();
  }, []);

  return (
    <>
      <style>{`
        .feat-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;}
        .fc{opacity:0;transform:translateY(26px);transition:opacity .55s cubic-bezier(.16,1,.3,1),transform .55s cubic-bezier(.16,1,.3,1),border-color .2s,box-shadow .2s;border-radius:22px;padding:28px;border:1.5px solid var(--border);background:var(--card);position:relative;overflow:hidden;}
        .fc::before{content:"";position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,77,0,.06),transparent);transition:left .55s ease;}
        .fc:hover{transform:translateY(-5px)!important;border-color:rgba(255,77,0,.22);box-shadow:0 22px 60px rgba(255,77,0,.08);}
        .fc:hover::before{left:100%;}
        .fc-tag{display:inline-block;font-size:10px;font-weight:700;padding:3px 10px;border-radius:99px;background:rgba(16,185,129,.1);color:#10B981;letter-spacing:.06em;text-transform:uppercase;margin-bottom:12px;}
        @media(max-width:960px){.feat-grid{grid-template-columns:repeat(2,minmax(0,1fr));}}
        @media(max-width:580px){.feat-grid{grid-template-columns:1fr;}}
      `}</style>

      <section
        id="features"
        style={{
          padding: sectionPadding,
          background: "var(--bg2)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            backgroundImage:
              "radial-gradient(rgba(255,77,0,.1) 1px,transparent 1px)",
            backgroundSize: "32px 32px",
            opacity: 0.14,
          }}
        />

        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="Features"
            title="Everything you need to grow and monetise on Instagram"
            description="Stop manually replying to the same questions. Start earning from content you've already created — while you sleep."
          />
          <div ref={ref} className="feat-grid">
            {features.map(
              ({ icon: Icon, color, tint, title, description, tag }, i) => (
                <div
                  key={title}
                  className="fc"
                  style={{ transitionDelay: `${i * 0.06}s` }}
                >
                  {tag && <span className="fc-tag">{tag}</span>}
                  <div
                    style={{
                      width: 50,
                      height: 50,
                      borderRadius: 16,
                      background: tint,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: 16,
                    }}
                  >
                    <Icon size={22} color={color} />
                  </div>
                  <h3
                    style={{
                      fontSize: 18,
                      fontWeight: 800,
                      color: "var(--text1)",
                      marginBottom: 9,
                      lineHeight: 1.25,
                    }}
                  >
                    {title}
                  </h3>
                  <p
                    style={{
                      fontSize: 14,
                      lineHeight: 1.78,
                      color: "var(--text3)",
                    }}
                  >
                    {description}
                  </p>
                </div>
              ),
            )}
          </div>
        </div>
      </section>
    </>
  );
}
