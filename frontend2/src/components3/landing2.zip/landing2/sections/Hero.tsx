"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Check,
  Zap,
  MessageCircle,
  ChevronRight,
} from "lucide-react";
import { brandGradient, landingContainerStyle } from "../landingTheme";

const trust = [
  "Free to start",
  "No credit card",
  "Official Meta API",
  "Works worldwide",
];

const FEED = [
  {
    handle: "@sofia.market",
    comment: "What's the price for your template?",
    keyword: "price",
    reply: "Hey Sofia! It's $49. Grab it here → boostlinkpro.com/template",
    delay: "0.4s",
  },
  {
    handle: "@jake.builds",
    comment: "Send me the link please!",
    keyword: "link",
    reply: "Here you go Jake! → boostlinkpro.com/link",
    delay: "0.3s",
  },
  {
    handle: "@priya.creates",
    comment: "How do I get the freebie?",
    keyword: "freebie",
    reply: "Sending it now Priya! Check your DMs →",
    delay: "0.5s",
  },
];

const STATS = [
  { value: "2.4M", label: "DMs sent" },
  { value: "98%", label: "Open rate" },
  { value: "< 1s", label: "Response time" },
];

export default function Hero() {
  const [activeFeed, setActiveFeed] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setActiveFeed((prev) => (prev + 1) % FEED.length);
    }, 3200);
    return () => clearInterval(t);
  }, []);

  return (
    <section
      style={{
        position: "relative",
        overflow: "hidden",
        background: "#080508",
        paddingTop: 80,
        paddingBottom: 0,
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@400;500;600;700&display=swap');

        .hero-root * { box-sizing: border-box; }

        /* Grid overlay */
        .hero-grid-bg {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255,255,255,.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,.03) 1px, transparent 1px);
          background-size: 48px 48px;
          pointer-events: none;
        }

        /* Radial glows */
        .hero-glow-a {
          position: absolute;
          top: -100px; left: -80px;
          width: 520px; height: 520px;
          background: radial-gradient(circle, rgba(255,60,0,.22) 0%, transparent 70%);
          pointer-events: none;
        }
        .hero-glow-b {
          position: absolute;
          top: 20px; right: -120px;
          width: 440px; height: 440px;
          background: radial-gradient(circle, rgba(255,100,150,.1) 0%, transparent 70%);
          pointer-events: none;
        }

        /* Layout */
        .hero-inner {
          position: relative;
          z-index: 2;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 48px;
          align-items: center;
          padding: 40px 0 0;
        }

        /* Left column */
        .hero-eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 6px 12px;
          border-radius: 999px;
          border: 1px solid rgba(255,80,0,.35);
          background: rgba(255,80,0,.1);
          color: #FF9166;
          font-family: 'DM Sans', sans-serif;
          font-size: 12px;
          font-weight: 600;
          letter-spacing: .02em;
          margin-bottom: 22px;
        }

        .hero-h1 {
          font-family: 'Instrument Serif', Georgia, serif;
          font-size: clamp(42px, 5.2vw, 68px);
          line-height: 1.04;
          color: #fff;
          letter-spacing: -0.02em;
          margin: 0 0 20px;
          font-weight: 400;
        }

        .hero-h1 em {
          font-style: italic;
          background: linear-gradient(90deg, #FF5C1A 0%, #FF9166 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .hero-subtext {
          font-family: 'DM Sans', sans-serif;
          font-size: 16px;
          line-height: 1.75;
          color: rgba(255,255,255,.6);
          max-width: 420px;
          margin: 0 0 30px;
        }

        .hero-actions {
          display: flex;
          gap: 10px;
          align-items: center;
          flex-wrap: wrap;
          margin-bottom: 28px;
        }

        .btn-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 0 22px;
          height: 48px;
          border-radius: 12px;
          background: linear-gradient(135deg, #FF4D00 0%, #FF8040 100%);
          color: #fff;
          font-family: 'DM Sans', sans-serif;
          font-size: 14px;
          font-weight: 700;
          text-decoration: none;
          box-shadow: 0 8px 32px rgba(255,77,0,.3), 0 1px 0 rgba(255,255,255,.12) inset;
          transition: transform .18s, box-shadow .18s;
        }
        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 14px 40px rgba(255,77,0,.4), 0 1px 0 rgba(255,255,255,.12) inset;
        }

        .btn-ghost {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 0 18px;
          height: 48px;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,.14);
          background: rgba(255,255,255,.05);
          color: rgba(255,255,255,.75);
          font-family: 'DM Sans', sans-serif;
          font-size: 14px;
          font-weight: 600;
          text-decoration: none;
          transition: border-color .18s, background .18s, transform .18s;
        }
        .btn-ghost:hover {
          border-color: rgba(255,255,255,.28);
          background: rgba(255,255,255,.09);
          transform: translateY(-2px);
        }

        .hero-trust {
          display: flex;
          flex-wrap: wrap;
          gap: 6px 18px;
        }
        .hero-trust-item {
          display: flex;
          align-items: center;
          gap: 7px;
          font-family: 'DM Sans', sans-serif;
          font-size: 12.5px;
          font-weight: 500;
          color: rgba(255,255,255,.5);
        }
        .trust-dot {
          width: 16px; height: 16px;
          border-radius: 50%;
          background: rgba(16,185,129,.14);
          border: 1px solid rgba(16,185,129,.3);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        /* Right column — mockup panel */
        .hero-panel {
          background: #100B0F;
          border-radius: 20px;
          border: 1px solid rgba(255,255,255,.1);
          overflow: hidden;
          position: relative;
        }
        .hero-panel::before {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 80% 0%, rgba(255,60,0,.1) 0%, transparent 50%);
          pointer-events: none;
        }

        /* Panel topbar */
        .panel-topbar {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 16px;
          border-bottom: 1px solid rgba(255,255,255,.07);
        }
        .panel-dots span {
          width: 9px; height: 9px;
          border-radius: 50%;
          display: inline-block;
          margin-right: 4px;
        }
        .panel-url {
          flex: 1;
          background: rgba(255,255,255,.05);
          border: 1px solid rgba(255,255,255,.07);
          border-radius: 6px;
          padding: 5px 10px;
          font-family: 'DM Sans', monospace;
          font-size: 10.5px;
          color: rgba(255,255,255,.38);
          text-align: center;
        }

        /* Stats row */
        .panel-stats {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          border-bottom: 1px solid rgba(255,255,255,.07);
        }
        .panel-stat {
          padding: 14px 16px;
          text-align: center;
          border-right: 1px solid rgba(255,255,255,.07);
        }
        .panel-stat:last-child { border-right: none; }
        .panel-stat-val {
          font-family: 'Instrument Serif', serif;
          font-size: 22px;
          color: #fff;
          display: block;
          line-height: 1;
          margin-bottom: 3px;
        }
        .panel-stat-label {
          font-family: 'DM Sans', sans-serif;
          font-size: 10px;
          color: rgba(255,255,255,.38);
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: .06em;
        }

        /* Automation config row */
        .panel-config {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 16px;
          border-bottom: 1px solid rgba(255,255,255,.07);
          flex-wrap: wrap;
        }
        .config-label {
          font-family: 'DM Sans', sans-serif;
          font-size: 10.5px;
          color: rgba(255,255,255,.4);
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: .05em;
          margin-right: 4px;
        }
        .config-chip {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 4px 10px;
          border-radius: 99px;
          font-family: 'DM Sans', sans-serif;
          font-size: 11px;
          font-weight: 700;
        }
        .chip-keyword {
          background: rgba(255,80,0,.14);
          border: 1px solid rgba(255,80,0,.25);
          color: #FF9166;
        }
        .chip-action {
          background: rgba(16,185,129,.1);
          border: 1px solid rgba(16,185,129,.22);
          color: #34D399;
        }
        .chip-live {
          background: rgba(99,102,241,.12);
          border: 1px solid rgba(99,102,241,.25);
          color: #A5B4FC;
        }
        .config-arrow {
          color: rgba(255,255,255,.2);
          font-size: 12px;
        }
        .live-badge {
          margin-left: auto;
          display: flex;
          align-items: center;
          gap: 5px;
          font-family: 'DM Sans', sans-serif;
          font-size: 10px;
          font-weight: 700;
          color: #34D399;
        }
        .live-dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 0 2px rgba(16,185,129,.2);
          animation: pulse 2s ease-in-out infinite;
        }
        @keyframes pulse {
          0%, 100% { box-shadow: 0 0 0 2px rgba(16,185,129,.2); }
          50% { box-shadow: 0 0 0 5px rgba(16,185,129,.08); }
        }

        /* DM Feed */
        .panel-feed {
          padding: 14px 16px 16px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          min-height: 186px;
        }
        .feed-handle {
          font-family: 'DM Sans', sans-serif;
          font-size: 10px;
          font-weight: 700;
          color: rgba(255,255,255,.35);
          margin-bottom: 4px;
          padding-left: 2px;
        }
        .bubble-in {
          display: inline-block;
          max-width: 82%;
          padding: 9px 12px;
          border-radius: 14px 14px 14px 4px;
          background: rgba(255,255,255,.07);
          border: 1px solid rgba(255,255,255,.07);
          font-family: 'DM Sans', sans-serif;
          font-size: 12px;
          line-height: 1.5;
          color: rgba(255,255,255,.8);
        }
        .bubble-keyword {
          color: #FF8040;
          font-weight: 700;
        }
        .bubble-out-wrap {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
        }
        .bubble-out {
          display: inline-block;
          max-width: 86%;
          padding: 9px 12px;
          border-radius: 14px 14px 4px 14px;
          background: linear-gradient(135deg, #FF4D00, #FF7A40);
          font-family: 'DM Sans', sans-serif;
          font-size: 12px;
          line-height: 1.5;
          color: #fff;
          box-shadow: 0 8px 24px rgba(255,77,0,.22);
          position: relative;
        }
        .auto-badge {
          position: absolute;
          top: -9px;
          right: 8px;
          background: rgba(255,255,255,.22);
          border-radius: 99px;
          padding: 2px 7px;
          font-size: 9px;
          font-weight: 700;
          color: #fff;
          display: flex;
          align-items: center;
          gap: 3px;
        }
        .bubble-time {
          font-family: 'DM Sans', sans-serif;
          font-size: 9px;
          color: rgba(255,255,255,.25);
          margin-top: 3px;
          padding-right: 2px;
        }

        /* Feed fade animation */
        .feed-item {
          animation: feedIn .42s cubic-bezier(.16,1,.3,1) both;
        }
        @keyframes feedIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Bottom curve */
        .hero-curve {
          position: relative;
          margin-top: -1px;
          z-index: 3;
        }

        /* Responsive */
        @media (max-width: 900px) {
          .hero-inner {
            grid-template-columns: 1fr;
            text-align: center;
            padding: 24px 0 0;
          }
          .hero-subtext { margin-left: auto; margin-right: auto; }
          .hero-actions { justify-content: center; }
          .hero-trust { justify-content: center; }
          .hero-eyebrow { margin-left: auto; margin-right: auto; display: inline-flex; }
        }
        @media (max-width: 540px) {
          .btn-primary, .btn-ghost { width: 100%; justify-content: center; }
          .hero-actions { flex-direction: column; }
        }
      `}</style>

      <div className="hero-grid-bg" />
      <div className="hero-glow-a" />
      <div className="hero-glow-b" />

      <div className="hero-root" style={landingContainerStyle}>
        <div className="hero-inner">
          {/* ── LEFT: Copy ── */}
          <div>
            <div className="hero-eyebrow">
              <Zap size={11} color="#FF9166" fill="#FF9166" />
              Instagram DM automation
            </div>
            <h1 className="hero-h1">
              Turn Instagram comments
              <br />
              into <em>instant DMs and real sales</em>
              <br />
            </h1>
            <p className="hero-subtext">
              Someone drops a keyword on your post — they get a personal DM with
              your offer in under a second. Set it once, sell while you sleep.
            </p>
            <div className="hero-actions">
              <Link href="/auth/signup" className="btn-primary">
                Start free <ArrowRight size={15} />
              </Link>
              <a href="#how" className="btn-ghost">
                See how it works <ChevronRight size={14} />
              </a>
            </div>
            <div className="hero-trust">
              {trust.map((t) => (
                <div key={t} className="hero-trust-item">
                  <div className="trust-dot">
                    <Check size={9} color="#10B981" strokeWidth={2.5} />
                  </div>
                  {t}
                </div>
              ))}
            </div>
          </div>

          {/* ── RIGHT: Live mockup ── */}
          <div className="hero-panel">
            {/* Topbar */}
            <div className="panel-topbar">
              <div className="panel-dots">
                {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => (
                  <span key={c} style={{ background: c }} />
                ))}
              </div>
              <div className="panel-url">app.boostlinkpro.com</div>
            </div>

            {/* Stats */}
            <div className="panel-stats">
              {STATS.map((s) => (
                <div key={s.label} className="panel-stat">
                  <span className="panel-stat-val">{s.value}</span>
                  <span className="panel-stat-label">{s.label}</span>
                </div>
              ))}
            </div>

            {/* Config row */}
            <div className="panel-config">
              <span className="config-label">Rule</span>
              <span className="config-chip chip-keyword">
                <MessageCircle size={10} /> keyword match
              </span>
              <span className="config-arrow">→</span>
              <span className="config-chip chip-action">
                <Zap size={10} /> send DM
              </span>
              <span className="config-arrow">→</span>
              <span className="config-chip chip-live">live</span>
              <div className="live-badge">
                <div className="live-dot" />
                Active
              </div>
            </div>

            {/* DM feed */}
            <div className="panel-feed">
              {FEED.map(
                (item, i) =>
                  i === activeFeed && (
                    <div key={i}>
                      {/* Incoming */}
                      <div className="feed-item" style={{ marginBottom: 8 }}>
                        <div className="feed-handle">{item.handle}</div>
                        <div className="bubble-in">
                          {item.comment
                            .split(item.keyword)
                            .map((part, j, arr) => (
                              <span key={j}>
                                {part}
                                {j < arr.length - 1 && (
                                  <span className="bubble-keyword">
                                    {item.keyword}
                                  </span>
                                )}
                              </span>
                            ))}
                        </div>
                      </div>

                      {/* Outgoing */}
                      <div
                        className="feed-item bubble-out-wrap"
                        style={{ animationDelay: ".18s" }}
                      >
                        <div className="bubble-out">
                          <div className="auto-badge">
                            <Zap size={7} fill="white" color="white" /> Auto
                          </div>
                          {item.reply}
                        </div>
                        <div className="bubble-time">Sent in {item.delay}</div>
                      </div>
                    </div>
                  ),
              )}

              {/* Feed indicator dots */}
              <div
                style={{
                  display: "flex",
                  gap: 5,
                  justifyContent: "center",
                  marginTop: 4,
                }}
              >
                {FEED.map((_, i) => (
                  <div
                    key={i}
                    onClick={() => setActiveFeed(i)}
                    style={{
                      width: i === activeFeed ? 18 : 6,
                      height: 6,
                      borderRadius: 99,
                      background:
                        i === activeFeed ? "#FF6030" : "rgba(255,255,255,.15)",
                      cursor: "pointer",
                      transition: "all .3s ease",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Curve transition */}
      <div className="hero-curve">
        <svg
          viewBox="0 0 1440 64"
          fill="none"
          preserveAspectRatio="none"
          style={{ display: "block", width: "100%", height: 64 }}
        >
          <path
            d="M0 32C320 64 640 64 960 40C1120 28 1300 12 1440 0V64H0V32Z"
            fill="var(--bg)"
          />
        </svg>
      </div>
    </section>
  );
}
