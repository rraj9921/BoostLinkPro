"use client";
import { useEffect, useRef } from "react";
import { ArrowRight, Instagram, Settings2, TrendingUp } from "lucide-react";
import SectionIntro from "../SectionIntro";
import { landingContainerStyle, sectionPadding } from "../landingTheme";

const steps = [
  { n:"01", icon:Instagram, color:"#FF4D00", tint:"rgba(255,77,0,.1)", title:"Connect your Instagram", desc:"Link your Business or Creator account in minutes. Log in, grant permissions, done. Takes under 2 minutes.", detail:"OAuth 2.0 · Secure · No credentials stored" },
  { n:"02", icon:Settings2, color:"#8B5CF6", tint:"rgba(139,92,246,.1)", title:"Set a keyword trigger", desc:"Choose any word. Write the DM you want sent. Toggle the automation on. No code, no technical setup.", detail:"Unlimited keywords · Any post or all posts" },
  { n:"03", icon:TrendingUp, color:"#10B981", tint:"rgba(16,185,129,.1)", title:"Earn on autopilot", desc:"Every matching comment fires your personalised message instantly — while you're creating, travelling, or asleep.", detail:"Runs 24/7 · Handles any volume" },
];

export default function HowItWorks() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const cards = ref.current?.querySelectorAll(".sc"); if(!cards) return;
    const obs = new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){(e.target as HTMLElement).style.opacity="1";(e.target as HTMLElement).style.transform="translateY(0)";}});},{threshold:.1});
    cards.forEach(c=>obs.observe(c)); return()=>obs.disconnect();
  },[]);

  return (
    <>
      <style>{`
        .steps-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:28px;}
        .sc{opacity:0;transform:translateY(26px);transition:opacity .6s cubic-bezier(.16,1,.3,1),transform .6s cubic-bezier(.16,1,.3,1),border-color .2s,box-shadow .2s;position:relative;border-radius:24px;padding:28px 24px;border:1.5px solid var(--border);background:var(--card);}
        .sc:hover{transform:translateY(-4px)!important;border-color:rgba(255,77,0,.2);box-shadow:0 20px 56px rgba(255,77,0,.07);}
        .sc-num{position:absolute;top:16px;right:18px;font-size:40px;font-weight:800;line-height:1;color:rgba(255,77,0,.07);}
        .sc-detail{display:inline-block;font-size:11px;fontWeight:600;color:var(--text4);margin-top:10px;padding:4px 10px;border-radius:99px;background:var(--bg2);}
        .scenario{border-radius:24px;border:1.5px solid var(--border);background:var(--card);padding:28px 32px;}
        .sg{display:grid;grid-template-columns:1fr auto 1fr;gap:18px;align-items:center;}
        .sbox-in{padding:16px 18px;border-radius:16px;border:1px solid var(--border);background:var(--bg2);}
        .sbox-out{padding:16px 18px;border-radius:16px;border:1.5px solid rgba(255,77,0,.2);background:rgba(255,77,0,.04);}
        @media(max-width:860px){.steps-row{grid-template-columns:1fr;}.sg{grid-template-columns:1fr;}}
      `}</style>

      <section id="how" style={{padding:sectionPadding,background:"var(--bg)",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,pointerEvents:"none",backgroundImage:"radial-gradient(var(--border2) 1px,transparent 1px)",backgroundSize:"28px 28px",opacity:.3}}/>
        <div style={landingContainerStyle}>
          <SectionIntro
            eyebrow="How it works"
            title="Live in under 10 minutes"
            description="No code. No technical setup. Connect your Instagram, pick your keywords, and your automation runs forever."
          />
          <div ref={ref} className="steps-row">
            {steps.map(({n,icon:Icon,color,tint,title,desc,detail},i)=>(
              <div key={n} className="sc" style={{transitionDelay:`${i*.1}s`}}>
                <span className="sc-num">{n}</span>
                <div style={{width:54,height:54,borderRadius:17,background:tint,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:18}}>
                  <Icon size={24} color={color}/>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
                  <h3 style={{fontSize:19,fontWeight:800,color:"var(--text1)",lineHeight:1.2,flex:1}}>{title}</h3>
                  <span style={{fontSize:11,fontWeight:700,color,background:`${color}14`,padding:"3px 9px",borderRadius:99,flexShrink:0}}>Step {n}</span>
                </div>
                <p style={{fontSize:14,lineHeight:1.75,color:"var(--text3)"}}>{desc}</p>
                <span className="sc-detail">{detail}</span>
              </div>
            ))}
          </div>

          {/* Scenario demo */}
          <div className="scenario">
            <div style={{position:"absolute",top:0,left:0,right:0,height:3,borderRadius:"24px 24px 0 0",background:"linear-gradient(90deg,#FF4D00,#FF8C42,#FFB347)"}}/>
            <p style={{fontSize:11,fontWeight:800,letterSpacing:"0.14em",textTransform:"uppercase",color:"#FF4D00",textAlign:"center",marginBottom:24}}>Real example — what happens in 0.3 seconds</p>
            <div className="sg">
              <div className="sbox-in">
                <p style={{fontSize:11,fontWeight:700,color:"var(--text4)",marginBottom:8,textTransform:"uppercase",letterSpacing:"0.08em"}}>Fan comments on your post</p>
                <p style={{fontSize:15,color:"var(--text2)",lineHeight:1.6}}>"This is exactly what I needed! What's the <strong style={{color:"#FF4D00"}}>price</strong>?"</p>
              </div>
              <div style={{textAlign:"center"}}>
                <div style={{width:48,height:48,borderRadius:"50%",margin:"0 auto 8px",display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(255,77,0,.09)",border:"1px solid rgba(255,77,0,.2)"}}>
                  <ArrowRight size={20} color="#FF4D00"/>
                </div>
                <p style={{fontSize:10,fontWeight:800,color:"#FF4D00",letterSpacing:"0.1em"}}>INSTANT</p>
              </div>
              <div className="sbox-out">
                <p style={{fontSize:11,fontWeight:700,color:"#C94D0B",marginBottom:8,textTransform:"uppercase",letterSpacing:"0.08em"}}>They receive in DMs ⚡</p>
                {/* <p style={{fontSize:15,color:"var(--text2)",lineHeight:1.6}}>"Hey! My guide is $49 — grab it here 👉 <span style={{color:"#FF4D00",fontWeight:600"}}>link.boostlinkpro.com/guide</span>"</p> */}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}