import { landingContainerStyle } from "../landingTheme";

const badges = [
  { dot: "#FF4D00", label: "Instagram Graph API" },
  { dot: "#10B981", label: "Stripe Payments" },
  { dot: "#FF4D00", label: "Keyword DM triggers" },
  { dot: "#8B5CF6", label: "Real-time automation" },
  { dot: "#0EA5E9", label: "24/7 uptime" },
  { dot: "#F59E0B", label: "Works worldwide" },
  { dot: "#10B981", label: "Digital product delivery" },
  { dot: "#FF4D00", label: "Bio link store" },
];

export default function LogoBar() {
  return (
    <>
      <style>{`
        .lb-track{display:flex;gap:10px;width:max-content;animation:lbScroll 30s linear infinite;}
        .lb-track:hover{animation-play-state:paused;}
        .lb-chip{display:inline-flex;align-items:center;gap:9px;padding:11px 18px;border-radius:999px;border:1px solid var(--border);background:var(--card);white-space:nowrap;transition:border-color .2s;}
        .lb-chip:hover{border-color:rgba(255,77,0,.3);}
        @keyframes lbScroll{from{transform:translateX(0)}to{transform:translateX(-50%)}}
      `}</style>
      <section
        style={{
          background: "var(--bg)",
          padding: "20px 0 28px",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: "0 0 auto 0",
            height: 1,
            background:
              "linear-gradient(90deg,transparent,rgba(255,77,0,.15),transparent)",
          }}
        />
        <div style={{ ...landingContainerStyle, marginBottom: 16 }}>
          <p
            style={{
              textAlign: "center",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "var(--text4)",
            }}
          >
            Built on trusted infrastructure · Serving creators worldwide
          </p>
        </div>
        <div style={{ overflow: "hidden" }}>
          <div className="lb-track">
            {[...badges, ...badges].map((b, i) => (
              <div key={i} className="lb-chip">
                <span
                  style={{
                    width: 7,
                    height: 7,
                    borderRadius: "50%",
                    background: b.dot,
                    display: "inline-block",
                    flexShrink: 0,
                  }}
                />
                <span
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: "var(--text2)",
                  }}
                >
                  {b.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
